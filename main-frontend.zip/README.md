# Profile & Persistence Layer

Static, build-free profile services for the desktop shell. No `import`/`export`,
no bundler. Everything is a `window.*` global loaded with `<script>` tags.

## Files

| File | Responsibility |
| --- | --- |
| `profile-db.js` | IndexedDB `profile-db` v2 (stores `profiles`, `profile-state`, `system-config`). Never stores file bytes. |
| `profile-service.js` | Profile definitions, active profile, owner/admin password gates, authentication adapter, identity updates, events. |
| `persistence-service.js` | Validate / load / save / reset per-profile state (schema v3, including `lockScreen`), debounce, diagnostics, shell hooks. |
| `window-state.js` | Profile-scoped window snapshot bridge; restores through the shell's existing launch paths. |
| `boot.js` | Deterministic boot: profiles → active profile → VFS → state → apply → emit. |
| `profile-ui.js` | Shell locked/inert state; delegates the root lock UI to `LockScreenV2` when present. |
| `../system-config.js` | Profile-scoped virtual users/groups/permissions, startup/service metadata, audit, reset, rollback. |

Load order (in `<head>`, before the VFS scripts):

```html
<script src="./profile/profile-db.js"></script>
<script src="./profile/profile-service.js"></script>
<script src="./profile/persistence-service.js"></script>
<script src="./profile/window-state.js"></script>
<script src="./fs/types.js"></script>
<!-- … other fs scripts … -->
<script src="./fs/init.js"></script>
<script src="./profile/boot.js"></script>
<script src="./profile/profile-ui.js"></script>
<script src="./system-services.js"></script>
<script src="./system-config.js"></script>
```

`system-config.js` waits on `window.ProfileReady`, then loads only the active
profile's configuration. The desktop shell's boot block waits on `window.ProfileReady` before it queries
the DOM or renders windows.

## Public API

### `window.ProfileService`

```js
await ProfileService.init();                  // idempotent, creates/migrates metadata
ProfileService.getProfiles();                 // public [{ id, name, type, username, dbName, ... }]
ProfileService.listPublicProfiles();          // explicit login-screen projection
ProfileService.getProfile(id);                // copy or null (hidden ids work when explicit)
ProfileService.getActiveProfile();            // copy or null
ProfileService.resolveActive();               // profile for this tab (locked owner → guest)
await ProfileService.setActiveProfile(id);    // flush outgoing state, then reload
ProfileService.hasOwnerPassword();            // boolean
await ProfileService.setOwnerPassword(pwd);   // first-time setup (salted PBKDF2)
await ProfileService.unlock('owner', pwd);    // { ok, reason?, needsSetup? }
await ProfileService.authenticate({ username, password }); // { ok, profileId?, reason? }
await ProfileService.updateIdentity(id, { displayName, username });
await ProfileService.enableHiddenAdmin(pwd, { dev: true }); // explicit dev/recovery only
ProfileService.isUnlocked(id);
ProfileService.lock(id);
ProfileService.subscribe(fn);                 // returns unsubscribe
ProfileService.ready;                         // Promise (same as window.ProfileReady)
```

Invalid ids/types are rejected. `setActiveProfile` rejects with
`code === 'PROFILE_LOCKED'` when the owner is not unlocked. `getProfiles()`
removes `hidden` and auth fields and excludes the hidden administrator;
`getProfile('admin')` still works when a caller explicitly names it.
`authenticate()` returns only `{ ok, profileId?, reason? }`, uses generic
failures for unknown usernames, and never auto-grants administrator access.
`enableHiddenAdmin()` requires `{ dev: true }` or
`sessionStorage['desktop.devMode'] === '1'`, otherwise it throws
`DEV_MODE_REQUIRED`.

### `window.PersistenceService`

```js
await PersistenceService.loadProfileState(profileId);        // validated state
await PersistenceService.saveProfileState(profileId, state); // resolves after commit
PersistenceService.queueSave(profileId, partial);            // debounced (700 ms)
await PersistenceService.flush(profileId);                   // commit pending now
await PersistenceService.resetProfileState(profileId);       // settings only, never files
PersistenceService.collectState();                           // snapshot shell prefs
PersistenceService.applyState(profileId, state);
PersistenceService.bindAutoSave(profileId);
PersistenceService.getCachedState(profileId);
PersistenceService.validateState(state);                     // pure validator (schema v3)
PersistenceService.defaults();                               // code-level default state
```

`saveProfileState` only resolves after the IndexedDB transaction commits. A
storage failure rejects **and** emits `profile:state-error`; success is never
reported early.

### `window.SystemConfig`

`main/system-config.js` is the Phase 5 virtual configuration layer. It is a
simulation only; it never touches real Windows configuration.

```js
await SystemConfig.ready;                       // active profile's config loaded
SystemConfig.get();                             // config + revision/currentUser
SystemConfig.defaults();                        // immutable code-level defaults
SystemConfig.validate(raw, { strict: true });   // pure validator
await SystemConfig.replace(raw);                // full replacement
await SystemConfig.patch(partial);              // shallow section merge
await SystemConfig.setSection('users', users);
await SystemConfig.reset();                     // all sections
await SystemConfig.reset({ section: 'startup' });
await SystemConfig.rollback();                  // one-step undo
SystemConfig.check({ action: 'read', resource: 'vfs:documents' });
SystemConfig.can('configure', 'config:system');
SystemConfig.audit(20);
```

The active profile's simulated principal is `owner` or `guest`. Permission
checks use the user and its direct groups; any matching `deny` rule wins,
otherwise an `allow` rule allows, otherwise the result is default-deny.
`SystemConfig` rejects any attempt to load or write another profile's record
with `code === 'PROFILE_SCOPE'`.

### `window.ProfileWindowState`

```js
ProfileWindowState.create({ profileId, getWindows }); // bridge for one shell
ProfileWindowState.snapshot(windowsMap);              // serializable window map
ProfileWindowState.snapshotActive();                  // active bridge snapshot
await ProfileWindowState.flushActive();                // snapshot + flush now
```

The shell owns the live `windows` Map; this module only serializes restorable
fields. It refuses to queue after the active profile changes, so a late timer
cannot write one profile's geometry into another profile's state. The
authoritative snapshot replaces `state.windows` (it is not merged), which is
what makes closing the last window persist as an empty window set.

### `window.ProfileUI`

```js
await ProfileUI.ready;
ProfileUI.unlock();        // guest unlocks immediately; owner prompts
ProfileUI.lock();
ProfileUI.openSwitcher();
ProfileUI.isLocked();
```

On the root shell the lock markup has `data-lock-v2="true"`; `ProfileUI` then
delegates account cards, credentials, and reveal transitions to
`window.LockScreenV2` and only owns `_setLocked()` / `aria-hidden` plus window
flush behavior. `main/index.html` and `main/desktop-shell.html` keep the legacy
lock UI.

### Readiness contract

- `window.ProfileReady` — resolves after profile metadata, VFS, and state are ready.
- `window.VirtualFSReady` — preserved; resolves to the open `window.VFS`.

## Events

Dispatched as `CustomEvent` on `document` (also delivered to
`ProfileService.subscribe` listeners):

| Event | `detail` |
| --- | --- |
| `profile:ready` | `{ profile, profileId }` |
| `profile:changed` | `{ from, to }` |
| `profile:state-loaded` | `{ profileId, state, restored }` |
| `profile:state-saved` | `{ profileId, updatedAt, revision }` |
| `profile:state-error` | `{ profileId, operation, error }` |
| `profile:locked` | `{ profileId }` |
| `vfs:opened` | `{ profileId, dbName, username }` |
| `explorer:navigate` | `{ id }` (used to persist the last Explorer folder) |

## Storage schema

`profile-db` v2 (v1 records are preserved; the upgrade only adds the
`system-config` store):

```js
// profiles
{ id, name, type: 'guest'|'owner', username, dbName, description,
  createdAt, lastAccessAt, schemaVersion, initialized,
  auth: null | { algo, iterations, salt, hash, updatedAt } }

// profile-state
{ profileId, schemaVersion: 3, revision, updatedAt,
  data: {
    schemaVersion: 3,
    desktop: { wallpaper, wallpaperPaused, iconsVisible },
    settings: { theme, musicVolume, clippyVisible, cursorScheme, soundEnabled },
    apps: {
      lastExplorerFolder,
      windowsInitialized // false = fresh profile; true = restore exact set
    },
    windows: {
      "explorer": {
        appId: "explorer",
        left: 18, top: 12, width: 754, height: 462,
        maximized: false, minimized: false
      },
      "terminal-1": {
        appId: "terminal",
        left: 403, top: 237, width: 363, height: 239,
        maximized: false, minimized: true
      }
    },
    lockScreen: {
      clock: { enabled, showSeconds, format: '24h'|'12h', showDate },
      animation: {
        intensity: 'low'|'medium'|'high',
        parallax, particles, respectReducedMotion, pauseWhenHidden
      },
      widgets: {
        enabled,
        enabledIds: ['fun-fact', 'system-message'],
        rotation: 'on-interaction'|'interval'|'off'
      },
      audio: { enabled, ambientEnabled, effectsEnabled, volume },
      accounts: {
        showOwner, showGuest, showHiddenAccounts: false, allowAccountCreation
      },
      avatar: { kind: 'builtin'|'custom', value }
    }
  } }

// system-config
{ profileId, schemaVersion: 1, revision, updatedAt,
  data: {
    schemaVersion: 1,
    users: [{ id, displayName, enabled, groups }],
    groups: [{ id, displayName }],
    permissions: [{
      id, principalType, principalId, actions, resource, effect
    }],
    startup: [{ id, label, target, enabled, scope }],
    services: [{ id, label, startMode, status }]
  },
  previous: null | <previous validated data> // one-step rollback snapshot
}
```

State and system configuration are validated on every read and write. Unknown keys, wrong types,
out-of-range numbers, functions, DOM nodes, and circular objects are dropped.
A newer `schemaVersion` only reads known fields; malformed data falls back to
defaults without throwing. Version 1 records still load; version 2 records gain
validated `lockScreen` defaults on read and are written as version 3 on the
next save (the migration is additive — existing data is never rewritten in
place). Legacy geometry-only window entries are discarded because they have no
app identity. The shell then boots its default layout and writes a version 3
record on the next save.

### Persisted today

- Virtual files & recycle bin (existing VFS, per profile).
- Wallpaper pause state, desktop icon visibility.
- Music volume, Clippy visibility, cursor scheme, sound toggle.
- Theme id (stored; the shell currently only ships the plum theme).
- Last Explorer folder.
- Open windows per profile: app identity, restore bounds, maximized/minimized
  flags, and whether the profile has initialized its window set.
- Lock-screen preferences per profile: clock, animation, widgets, audio, account
  visibility, and the chosen/custom avatar. Passwords are never included.
- Profile metadata, timestamps, and owner/admin auth verifiers.
- Per-profile virtual system configuration, rollback snapshot, simulated
  users/groups/permissions, and startup/service metadata (`SystemConfig`).

Explicitly **not** persisted (transient by design): window focus, z-order,
in-progress drag/resize, hover, open context menus, toasts, selected icon, and
per-app scratch state. Window geometry is persisted; focus order is not.

## Profile isolation

VFS nodes had no profile field. Rather than rewriting node identity (which every
component relies on: `'root'`, `'c-drive'`, …), each profile gets its own
IndexedDB namespace using the **same VFS schema and code**:

| Profile | Database | Username | Existing data |
| --- | --- | --- | --- |
| `owner` | `vfs-db` (legacy) | `r3d1` | preserved unchanged |
| `guest` | `vfs-db-guest` | `guest` | created lazily, seeded independently |
| `admin` (hidden) | `vfs-db-admin` | `sysadmin` | only reachable by explicit id / dev setup |

`VFSService.open(profile)` constructs the canonical `VirtualFS` against that
namespace. A Guest `VirtualFS` instance only ever loads Guest nodes, so normal
simulator APIs cannot read, change, or delete owner files. There is no second
filesystem implementation and no duplicated content storage.

Migrations are per-namespace (`vfs-schema-version:<profileId>`) and only run
cycle/orphan repair. Existing owner data is not rewritten during this work.

## Security limitations

- **The owner password is a UI gate, not confidentiality.** The app is static
  and client-side. Anyone with the browser profile, IndexedDB access, or the
  ability to edit served JavaScript can read or bypass everything.
- The password is never hardcoded and never stored in plaintext: a random salt
  and a PBKDF2-SHA256 verifier (120 000 iterations) live in `profile-db`.
  Non-secure contexts fall back to an iterated FNV hash (weaker).
- The hidden `admin` account is excluded from public profile lists, but that is
  presentation, not protection. It has no password until
  `enableHiddenAdmin(pwd, { dev: true })` is called deliberately; it grants no
  real OS privileges and remains a browser-only simulation.
- Session unlock (`sessionStorage`) survives reload in the same tab and is
  cleared when the tab closes. This is convenience, not security.
- Multi-tab: each tab has its own `sessionStorage` profile selection. Two tabs
  on the same profile share state (last write wins, serialized per tab). Two
  tabs on different profiles are isolated by database.

## Boot sequence

1. `ProfileService.init()` — create/migrate `guest` and `owner` metadata.
2. Resolve this tab's profile (`sessionStorage`, locked owner → Guest).
3. `VFSService.open(active)` — open the matching VFS namespace.
4. `PersistenceService.loadProfileState(active)` — validate saved state.
5. Write localStorage/sessionStorage preference keys *before* the shell boots.
6. After DOM ready: apply DOM preferences (slider, theme, icons, cursor).
7. `bindAutoSave(active)` — VFS events + shell controls → debounced saves.
8. Emit `profile:ready` / `profile:state-loaded`; unlock the shell.

Profile switching flushes the outgoing profile, records the new active profile,
and reloads. The reload guarantees no window/selection/application state leaks
between profiles and that the incoming profile's state is applied before render.

## Reset

`resetProfileState(profileId)` writes defaults back to that profile's state
record. It never touches VFS nodes, file contents, or the recycle bin. Full
profile deletion is intentionally not implemented.

`SystemConfig.reset()` is separate: it restores the virtual configuration
(users, groups, permissions, startup entries, and service metadata) for the
active profile only. It does not change files, shell settings, windows, or the
profile record, and its previous snapshot remains available to
`SystemConfig.rollback()`.

## Manual test checklist

Run from the repo root with `python -m http.server 8899`, then open
`http://localhost:8899/index.html`.

1. Fresh browser state → Guest profile boots; desktop and Explorer render.
2. Create `guest-test.txt` on the desktop → reload → file is still there.
3. Change volume / pause wallpaper → reload → both restored.
4. Owner chip → set a password → shell reloads into `r3d1bruh` with separate files.
5. Create an owner file → switch to Guest → owner file is not visible.
6. Switch back to Owner → password prompt → correct password → owner state restored.
7. Reload with a locked owner session → Guest boots; owner data is not exposed.
8. Corrupt `profile-state` in DevTools → reload → defaults, no crash.
9. Reload repeatedly → profiles, files, and icons are not duplicated.
10. Reset settings → virtual files and recycle bin remain intact.
11. Simulate a failed write (see below) → `profile:state-error` fires and save rejects.
12. Open `main/desktop-shell.html` → profile layer works without the lock screen.
13. `await SystemConfig.ready` → the active profile config loads; `get()` reports revision and current user.
14. `await SystemConfig.patch({...})` → reload → the configuration persists; reset and rollback restore the expected virtual config without changing files.
15. Switch Guest ↔ Owner → each profile reads its own `system-config` record; a cross-profile load/write rejects with `PROFILE_SCOPE`.
16. Root lock screen → Owner and Guest cards render, no administrator card; Guest signs in; unknown usernames fail generically.
17. Owner with no password → first-run password setup appears; after setup, the owner session activates.
18. Change clock/animation/widget/avatar settings → reload → settings persist for that profile only; a custom avatar is re-encoded to WebP.
19. Sign out from the lock-screen settings → the session locks and returns to the lock screen (Owner/Admin return through Guest).

Simulated failure:

```js
const db = ProfileService._db;
const original = db.putState.bind(db);
db.putState = async () => { throw new Error('quota'); };
await PersistenceService.saveProfileState('guest', { settings: { musicVolume: 10 } })
  .catch(e => console.log('rejected as expected', e.message));
db.putState = original;
```

## Remaining work

- Control Panel theme buttons are cosmetic; `state.settings.theme` is stored but
  only one theme ships.
- Multi-tab writes are last-write-wins per profile (documented above).
- `main/index.html` and `main/desktop-shell.html` are legacy duplicates of the
  root shell. They load the same shared services, but only the root page has the
  lock screen.
